import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { addreminderPage } from "../reminder/addreminder";

@NgModule({
  declarations: [
    addreminderPage,
  ],
  imports: [
    IonicPageModule.forChild(addreminderPage),
  ],
})
export class MapPageModule {}